import { createBrowserRouter } from "react-router";
import { RootLayout } from "./components/layouts/RootLayout";
import { Dashboard } from "./components/views/Dashboard";
import { Manifest } from "./components/views/Manifest";
import { HangarDisplay } from "./components/views/HangarDisplay";
import { Equipment } from "./components/views/Equipment";
import { Events } from "./components/views/Events";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: RootLayout,
    children: [
      { index: true, Component: Dashboard },
      { path: "manifest", Component: Manifest },
      { path: "hangar", Component: HangarDisplay },
      { path: "equipment", Component: Equipment },
      { path: "events", Component: Events },
    ],
  },
]);
