import { useState, useEffect } from "react";
import { Plane, Users, Clock } from "lucide-react";

interface LoadInfo {
  number: number;
  status: "Przed wejściem" | "Wsiadanie" | "W powietrzu" | "Lądowanie";
  jumpers: string[];
}

export function HangarDisplay() {
  const [countdown, setCountdown] = useState(847);
  const [loads, setLoads] = useState<LoadInfo[]>([
    { number: 1, status: "W powietrzu", jumpers: ["Anna K.", "Piotr N.", "Ewa W.", "Katarzyna Z.", "Tomasz W.", "Jakub M.", "Agata S.", "Krzysztof P."] },
    { number: 2, status: "Wsiadanie", jumpers: ["Jan K.", "Maria G.", "Kevin L.", "Zofia R.", "Dawid K.", "Nina B."] },
    { number: 3, status: "Przed wejściem", jumpers: ["Aleksander T.", "Renata M.", "Robert H.", "Julia N."] },
  ]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const getStatusColor = (status: LoadInfo["status"]) => {
    switch (status) {
      case "W powietrzu":
        return "bg-[#007FFF] text-white";
      case "Wsiadanie":
        return "bg-[#f59e0b] text-white";
      case "Przed wejściem":
        return "bg-[#64748b] text-white";
      default:
        return "bg-[#22c55e] text-white";
    }
  };

  return (
    <div className="min-h-screen bg-[#e2e8f0] p-8">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg border-2 border-[#007FFF] p-8 mb-6">
          <div className="text-center">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Clock className="w-8 h-8 text-[#007FFF]" />
              <h2 className="text-xl text-[#1e293b]">Następny Start</h2>
            </div>
            <div className="text-7xl text-[#007FFF] mb-2" style={{ fontVariantNumeric: "tabular-nums" }}>
              {formatTime(countdown)}
            </div>
            <p className="text-[#64748b]">Rejs 2 - Przygotowanie do odlotu</p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg border border-[rgba(0,0,0,0.1)] overflow-hidden">
          <div className="bg-[#007FFF] text-white px-6 py-4">
            <h1 className="flex items-center gap-3">
              <Plane className="w-6 h-6" />
              Status Aktywnych Rejsów
            </h1>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-[#f8fafc] border-b-2 border-[rgba(0,0,0,0.1)]">
                <tr>
                  <th className="px-6 py-4 text-left text-[#1e293b]">Rejs #</th>
                  <th className="px-6 py-4 text-left text-[#1e293b]">Status</th>
                  <th className="px-6 py-4 text-left text-[#1e293b]">Skoczkowie</th>
                  <th className="px-6 py-4 text-left text-[#1e293b]">Liczba</th>
                </tr>
              </thead>
              <tbody>
                {loads.map((load) => (
                  <tr key={load.number} className="border-b border-[rgba(0,0,0,0.06)] hover:bg-[#f8fafc] transition-colors">
                    <td className="px-6 py-6">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-[#e0f2fe] flex items-center justify-center">
                          <span className="text-xl text-[#007FFF]">{load.number}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-6">
                      <span className={`px-4 py-2 rounded-lg ${getStatusColor(load.status)}`}>
                        {load.status}
                      </span>
                    </td>
                    <td className="px-6 py-6">
                      <div className="flex flex-wrap gap-2">
                        {load.jumpers.map((jumper, idx) => (
                          <span
                            key={idx}
                            className="bg-[#f1f5f9] text-[#1e293b] px-3 py-1 rounded-lg text-sm"
                          >
                            {jumper}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="px-6 py-6">
                      <div className="flex items-center gap-2">
                        <Users className="w-5 h-5 text-[#007FFF]" />
                        <span className="text-xl text-[#1e293b]">{load.jumpers.length}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-6 bg-[#fff5e6] border-2 border-[#f59e0b] rounded-xl p-4">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="whitespace-nowrap text-[#1e293b] shrink-0">🔔 Alerty Bezpieczeństwa:</div>
            <div className="animate-marquee whitespace-nowrap text-[#64748b]">
              Następny briefing bezpieczeństwa: 14:00 w głównym hangarze • Wszyscy skoczkowie muszą zameldować się 30 minut przed lotem • Aktualizacja pogody o 15:00 • Skoki o zachodzie słońca dostępne dzisiaj do 18:45
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-marquee {
          display: inline-block;
          animation: marquee 30s linear infinite;
        }
      `}</style>
    </div>
  );
}
