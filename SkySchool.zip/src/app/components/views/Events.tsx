import { useState } from "react";
import { Calendar, Plus, Users, MapPin, Clock, Edit, Trash2, ChevronRight } from "lucide-react";
import { format, addDays, addWeeks } from "date-fns";
import { pl } from "date-fns/locale";

interface Event {
  id: string;
  title: string;
  type: "Boogie" | "Kurs AFF" | "Tandem Event" | "Zawody" | "Szkolenie" | "Inne";
  date: Date;
  endDate?: Date;
  location: string;
  participants: number;
  maxParticipants: number;
  instructor?: string;
  description: string;
  status: "Planowany" | "W trakcie" | "Zakończony" | "Anulowany";
}

export function Events() {
  const [showModal, setShowModal] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [events, setEvents] = useState<Event[]>([
    {
      id: "1",
      title: "Weekend Tandem Boogie",
      type: "Boogie",
      date: addDays(new Date(), 5),
      endDate: addDays(new Date(), 7),
      location: "Skoczów Dropzone",
      participants: 24,
      maxParticipants: 40,
      description: "Weekendowy event tandemowy dla nowych skoczków. Zniżki dla grup!",
      status: "Planowany",
    },
    {
      id: "2",
      title: "Kurs AFF Poziom 1-3",
      type: "Kurs AFF",
      date: addWeeks(new Date(), 1),
      endDate: addWeeks(new Date(), 2),
      location: "Skoczów Dropzone",
      participants: 8,
      maxParticipants: 12,
      instructor: "Piotr Nowak",
      description: "Intensywny kurs AFF dla początkujących. Pierwsze 3 poziomy.",
      status: "Planowany",
    },
    {
      id: "3",
      title: "Mistrzostwa Polski w Formacjach",
      type: "Zawody",
      date: addWeeks(new Date(), 3),
      endDate: addWeeks(new Date(), 3.5),
      location: "Gliwice Aerodrom",
      participants: 45,
      maxParticipants: 60,
      description: "Krajowe zawody w formacjach 4-way i 8-way.",
      status: "Planowany",
    },
    {
      id: "4",
      title: "Szkolenie Instruktorów",
      type: "Szkolenie",
      date: addWeeks(new Date(), 2),
      location: "Skoczów Dropzone",
      participants: 12,
      maxParticipants: 15,
      instructor: "Anna Kowalska",
      description: "Szkolenie dla kandydatów na instruktorów AFF.",
      status: "Planowany",
    },
    {
      id: "5",
      title: "Sunset Jumps Festival",
      type: "Inne",
      date: addDays(new Date(), 14),
      location: "Skoczów Dropzone",
      participants: 32,
      maxParticipants: 50,
      description: "Wieczorne skoki o zachodzie słońca z afterparty.",
      status: "Planowany",
    },
  ]);

  const getEventTypeColor = (type: Event["type"]) => {
    switch (type) {
      case "Boogie":
        return "bg-[#007FFF] text-white";
      case "Kurs AFF":
        return "bg-[#22c55e] text-white";
      case "Tandem Event":
        return "bg-[#f59e0b] text-white";
      case "Zawody":
        return "bg-[#ef4444] text-white";
      case "Szkolenie":
        return "bg-[#8b5cf6] text-white";
      default:
        return "bg-[#64748b] text-white";
    }
  };

  const getStatusColor = (status: Event["status"]) => {
    switch (status) {
      case "Planowany":
        return "text-[#007FFF] bg-[#e0f2fe]";
      case "W trakcie":
        return "text-[#22c55e] bg-[#dcfce7]";
      case "Zakończony":
        return "text-[#64748b] bg-[#f1f5f9]";
      case "Anulowany":
        return "text-[#ef4444] bg-[#fee2e2]";
      default:
        return "text-[#64748b] bg-[#f1f5f9]";
    }
  };

  const sortedEvents = [...events].sort((a, b) => a.date.getTime() - b.date.getTime());

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-[#1e293b] mb-1">Organizacja Eventów</h1>
          <p className="text-[#64748b]">Zarządzaj kursami, zawodami i wydarzeniami</p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="bg-[#007FFF] text-white px-6 py-3 rounded-xl flex items-center gap-2 hover:bg-[#0066cc] transition-colors"
        >
          <Plus className="w-5 h-5" />
          Dodaj Event
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-xl border-2 border-[#007FFF] p-6 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <div className="w-12 h-12 rounded-full bg-[#e0f2fe] flex items-center justify-center">
              <Calendar className="w-6 h-6 text-[#007FFF]" />
            </div>
          </div>
          <div className="text-3xl text-[#1e293b] mb-1">
            {events.filter((e) => e.status === "Planowany").length}
          </div>
          <div className="text-[#64748b]">Zaplanowanych Eventów</div>
        </div>

        <div className="bg-white rounded-xl border-2 border-[#007FFF] p-6 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <div className="w-12 h-12 rounded-full bg-[#e0f2fe] flex items-center justify-center">
              <Users className="w-6 h-6 text-[#007FFF]" />
            </div>
          </div>
          <div className="text-3xl text-[#1e293b] mb-1">
            {events.reduce((sum, e) => sum + e.participants, 0)}
          </div>
          <div className="text-[#64748b]">Wszystkich Uczestników</div>
        </div>

        <div className="bg-white rounded-xl border-2 border-[#007FFF] p-6 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <div className="w-12 h-12 rounded-full bg-[#e0f2fe] flex items-center justify-center">
              <Calendar className="w-6 h-6 text-[#007FFF]" />
            </div>
          </div>
          <div className="text-3xl text-[#1e293b] mb-1">
            {events.filter((e) => e.date >= new Date() && e.date <= addDays(new Date(), 7)).length}
          </div>
          <div className="text-[#64748b]">Eventów w Tym Tygodniu</div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {sortedEvents.map((event) => {
          const participantPercentage = (event.participants / event.maxParticipants) * 100;

          return (
            <div
              key={event.id}
              className="bg-white rounded-xl border border-[rgba(0,0,0,0.08)] p-6 shadow-sm hover:shadow-md transition-all cursor-pointer"
              onClick={() => setSelectedEvent(event)}
            >
              <div className="flex items-start gap-6">
                <div className="shrink-0">
                  <div className="bg-[#e0f2fe] rounded-xl p-4 text-center w-20">
                    <div className="text-2xl text-[#007FFF]">
                      {format(event.date, "d")}
                    </div>
                    <div className="text-sm text-[#64748b] uppercase">
                      {format(event.date, "MMM", { locale: pl })}
                    </div>
                  </div>
                </div>

                <div className="flex-1">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-[#1e293b]">{event.title}</h3>
                        <span className={`px-3 py-1 rounded-lg text-sm ${getEventTypeColor(event.type)}`}>
                          {event.type}
                        </span>
                        <span className={`px-3 py-1 rounded-lg text-sm ${getStatusColor(event.status)}`}>
                          {event.status}
                        </span>
                      </div>
                      <p className="text-[#64748b] mb-3">{event.description}</p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-[#64748b]" />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div className="flex items-center gap-2 text-sm">
                      <Clock className="w-4 h-4 text-[#007FFF]" />
                      <span className="text-[#64748b]">
                        {event.endDate
                          ? `${format(event.date, "d MMM", { locale: pl })} - ${format(event.endDate, "d MMM", { locale: pl })}`
                          : format(event.date, "d MMMM yyyy", { locale: pl })}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="w-4 h-4 text-[#007FFF]" />
                      <span className="text-[#64748b]">{event.location}</span>
                    </div>
                    {event.instructor && (
                      <div className="flex items-center gap-2 text-sm">
                        <Users className="w-4 h-4 text-[#007FFF]" />
                        <span className="text-[#64748b]">Instruktor: {event.instructor}</span>
                      </div>
                    )}
                  </div>

                  <div>
                    <div className="flex items-center justify-between text-sm mb-2">
                      <span className="text-[#64748b]">Uczestnicy</span>
                      <span className="text-[#1e293b]">
                        {event.participants} / {event.maxParticipants}
                      </span>
                    </div>
                    <div className="w-full bg-[#f1f5f9] rounded-full h-2">
                      <div
                        className="bg-[#007FFF] h-2 rounded-full transition-all"
                        style={{ width: `${participantPercentage}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {selectedEvent && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-8 z-50"
          onClick={() => setSelectedEvent(null)}
        >
          <div
            className="bg-white rounded-xl max-w-2xl w-full p-8"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between mb-6">
              <div>
                <h2 className="text-[#1e293b] mb-2">{selectedEvent.title}</h2>
                <div className="flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-lg text-sm ${getEventTypeColor(selectedEvent.type)}`}>
                    {selectedEvent.type}
                  </span>
                  <span className={`px-3 py-1 rounded-lg text-sm ${getStatusColor(selectedEvent.status)}`}>
                    {selectedEvent.status}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setSelectedEvent(null)}
                className="text-[#64748b] hover:text-[#1e293b]"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 mb-6">
              <div>
                <div className="text-sm text-[#64748b] mb-1">Opis</div>
                <p className="text-[#1e293b]">{selectedEvent.description}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm text-[#64748b] mb-1">Data</div>
                  <div className="text-[#1e293b]">
                    {selectedEvent.endDate
                      ? `${format(selectedEvent.date, "d MMM", { locale: pl })} - ${format(selectedEvent.endDate, "d MMM yyyy", { locale: pl })}`
                      : format(selectedEvent.date, "d MMMM yyyy", { locale: pl })}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-[#64748b] mb-1">Lokalizacja</div>
                  <div className="text-[#1e293b]">{selectedEvent.location}</div>
                </div>
              </div>

              {selectedEvent.instructor && (
                <div>
                  <div className="text-sm text-[#64748b] mb-1">Instruktor</div>
                  <div className="text-[#1e293b]">{selectedEvent.instructor}</div>
                </div>
              )}

              <div>
                <div className="text-sm text-[#64748b] mb-2">
                  Uczestnicy: {selectedEvent.participants} / {selectedEvent.maxParticipants}
                </div>
                <div className="w-full bg-[#f1f5f9] rounded-full h-3">
                  <div
                    className="bg-[#007FFF] h-3 rounded-full transition-all"
                    style={{ width: `${(selectedEvent.participants / selectedEvent.maxParticipants) * 100}%` }}
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <button className="flex-1 bg-[#007FFF] text-white px-6 py-3 rounded-xl hover:bg-[#0066cc] transition-colors flex items-center justify-center gap-2">
                <Edit className="w-5 h-5" />
                Edytuj
              </button>
              <button className="bg-[#ef4444] text-white px-6 py-3 rounded-xl hover:bg-[#dc2626] transition-colors flex items-center justify-center gap-2">
                <Trash2 className="w-5 h-5" />
                Usuń
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
