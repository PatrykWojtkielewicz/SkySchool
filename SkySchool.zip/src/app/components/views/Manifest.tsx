import { useState } from "react";
import { DndProvider, useDrag, useDrop } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import { CheckCircle2, AlertCircle, User, Plane, Plus } from "lucide-react";

interface Jumper {
  id: string;
  name: string;
  license: string;
  documentsOk: boolean;
  medicalExpired: boolean;
  jumpNumber: number;
  avatar: string;
}

interface Load {
  id: string;
  name: string;
  capacity: number;
  jumpers: Jumper[];
}

const ItemType = "JUMPER";

function JumperCard({ jumper }: { jumper: Jumper }) {
  const [{ isDragging }, drag] = useDrag({
    type: ItemType,
    item: { jumperId: jumper.id },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  return (
    <div
      ref={drag}
      className={`bg-white rounded-xl border p-4 cursor-move transition-all ${
        isDragging ? "opacity-50" : "opacity-100"
      } ${
        jumper.medicalExpired
          ? "border-[#ef4444]"
          : jumper.documentsOk
          ? "border-[#22c55e]"
          : "border-[rgba(0,0,0,0.08)]"
      }`}
    >
      <div className="flex items-center gap-3 mb-3">
        <div className="w-10 h-10 rounded-full bg-[#e0f2fe] flex items-center justify-center">
          <User className="w-5 h-5 text-[#007FFF]" />
        </div>
        <div className="flex-1">
          <div className="text-[#1e293b]">{jumper.name}</div>
          <div className="text-sm text-[#64748b]">{jumper.license}</div>
        </div>
      </div>

      <div className="flex items-center gap-2 text-sm">
        {jumper.documentsOk ? (
          <div className="flex items-center gap-1 text-[#22c55e]">
            <CheckCircle2 className="w-4 h-4" />
            <span>Dokumenty OK</span>
          </div>
        ) : (
          <div className="flex items-center gap-1 text-[#f59e0b]">
            <AlertCircle className="w-4 h-4" />
            <span>Sprawdź Dok.</span>
          </div>
        )}

        {jumper.medicalExpired && (
          <div className="flex items-center gap-1 text-[#ef4444]">
            <AlertCircle className="w-4 h-4" />
            <span>Badania Wygasły</span>
          </div>
        )}
      </div>

      <div className="mt-2 text-sm text-[#64748b]">
        Skok #{jumper.jumpNumber}
      </div>
    </div>
  );
}

function LoadSlot({ load, onDrop }: { load: Load; onDrop: (jumperId: string, loadId: string) => void }) {
  const [{ isOver }, drop] = useDrop({
    accept: ItemType,
    drop: (item: { jumperId: string }) => {
      onDrop(item.jumperId, load.id);
    },
    collect: (monitor) => ({
      isOver: monitor.isOver(),
    }),
  });

  const fillPercentage = (load.jumpers.length / load.capacity) * 100;

  return (
    <div
      ref={drop}
      className={`bg-white rounded-xl border-2 p-6 transition-all ${
        isOver ? "border-[#007FFF] bg-[#e0f2fe]" : "border-[rgba(0,0,0,0.08)]"
      }`}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Plane className="w-5 h-5 text-[#007FFF]" />
          <h3 className="text-[#1e293b]">{load.name}</h3>
        </div>
        <span className="text-sm text-[#64748b]">
          {load.jumpers.length}/{load.capacity}
        </span>
      </div>

      <div className="w-full bg-[#f1f5f9] rounded-full h-3 mb-4">
        <div
          className="bg-[#007FFF] h-3 rounded-full transition-all"
          style={{ width: `${fillPercentage}%` }}
        />
      </div>

      <div className="space-y-2 min-h-[200px]">
        {load.jumpers.map((jumper) => (
          <div key={jumper.id} className="bg-[#f8fafc] rounded-lg p-3 border border-[rgba(0,0,0,0.06)]">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-[#e0f2fe] flex items-center justify-center">
                <User className="w-4 h-4 text-[#007FFF]" />
              </div>
              <div>
                <div className="text-sm text-[#1e293b]">{jumper.name}</div>
                <div className="text-xs text-[#64748b]">{jumper.license}</div>
              </div>
            </div>
          </div>
        ))}
        {load.jumpers.length === 0 && (
          <div className="text-center text-[#64748b] py-8">
            Przeciągnij skoczków tutaj
          </div>
        )}
      </div>
    </div>
  );
}

function ManifestContent() {
  const [jumpers, setJumpers] = useState<Jumper[]>([
    { id: "1", name: "Anna Kowalska", license: "Licencja A", documentsOk: true, medicalExpired: false, jumpNumber: 145, avatar: "" },
    { id: "2", name: "Piotr Nowak", license: "Licencja B", documentsOk: true, medicalExpired: false, jumpNumber: 456, avatar: "" },
    { id: "3", name: "Ewa Wiśniewska", license: "Licencja C", documentsOk: false, medicalExpired: false, jumpNumber: 892, avatar: "" },
    { id: "4", name: "Jan Kowalski", license: "Student", documentsOk: true, medicalExpired: true, jumpNumber: 12, avatar: "" },
    { id: "5", name: "Katarzyna Zielińska", license: "Licencja D", documentsOk: true, medicalExpired: false, jumpNumber: 1245, avatar: "" },
    { id: "6", name: "Tomasz Wójcik", license: "Licencja A", documentsOk: true, medicalExpired: false, jumpNumber: 234, avatar: "" },
  ]);

  const [loads, setLoads] = useState<Load[]>([
    { id: "load1", name: "Rejs 1", capacity: 12, jumpers: [] },
    { id: "load2", name: "Rejs 2", capacity: 12, jumpers: [] },
    { id: "load3", name: "Rejs 3", capacity: 12, jumpers: [] },
  ]);

  const handleDrop = (jumperId: string, loadId: string) => {
    const jumper = jumpers.find((j) => j.id === jumperId);
    if (!jumper) return;

    setLoads((prevLoads) =>
      prevLoads.map((load) => {
        if (load.id === loadId && load.jumpers.length < load.capacity) {
          const alreadyInLoad = load.jumpers.some((j) => j.id === jumperId);
          if (!alreadyInLoad) {
            return { ...load, jumpers: [...load.jumpers, jumper] };
          }
        }
        return {
          ...load,
          jumpers: load.jumpers.filter((j) => j.id !== jumperId),
        };
      })
    );
  };

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-[#1e293b] mb-1">Kontrola Manifestu</h1>
          <p className="text-[#64748b]">Przypisz skoczków do rejsów</p>
        </div>
        <button className="bg-[#007FFF] text-white px-6 py-3 rounded-xl flex items-center gap-2 hover:bg-[#0066cc] transition-colors">
          <Plus className="w-5 h-5" />
          Dodaj Skoczka
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1">
          <h2 className="text-[#1e293b] mb-4">Dostępni Skoczkowie</h2>
          <div className="space-y-3">
            {jumpers.map((jumper) => (
              <JumperCard key={jumper.id} jumper={jumper} />
            ))}
          </div>
        </div>

        <div className="lg:col-span-3">
          <h2 className="text-[#1e293b] mb-4">Aktywne Rejsy</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {loads.map((load) => (
              <LoadSlot key={load.id} load={load} onDrop={handleDrop} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export function Manifest() {
  return (
    <DndProvider backend={HTML5Backend}>
      <ManifestContent />
    </DndProvider>
  );
}
