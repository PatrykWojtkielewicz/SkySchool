import { Users, Plane, Calendar, Cloud, Wind, AlertCircle } from "lucide-react";
import { format, addDays } from "date-fns";
import { pl } from "date-fns/locale";

export function Dashboard() {
  const today = new Date();
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(today, i));

  const events = [
    { date: today, time: "09:00", title: "AFF Poziom 1 - Jan Kowalski", type: "course" },
    { date: today, time: "10:30", title: "Briefing Tandem (Grupa 6 osób)", type: "briefing" },
    { date: today, time: "14:00", title: "Coaching - Anna Nowak", type: "coaching" },
    { date: addDays(today, 1), time: "08:00", title: "AFF Poziom 3 - Piotr Wiśniewski", type: "course" },
    { date: addDays(today, 2), time: "09:00", title: "Weekendowy Event Tandem", type: "event" },
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-[#1e293b] mb-1">Panel Główny</h1>
        <p className="text-[#64748b]">{format(today, "EEEE, d MMMM yyyy", { locale: pl })}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-xl border-2 border-[#007FFF] p-6 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <div className="w-12 h-12 rounded-full bg-[#e0f2fe] flex items-center justify-center">
              <Plane className="w-6 h-6 text-[#007FFF]" />
            </div>
            <span className="text-[#007FFF] text-sm">Dziś</span>
          </div>
          <div className="text-3xl text-[#1e293b] mb-1">4</div>
          <div className="text-[#64748b]">Aktywne Rejsy</div>
        </div>

        <div className="bg-white rounded-xl border-2 border-[#007FFF] p-6 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <div className="w-12 h-12 rounded-full bg-[#e0f2fe] flex items-center justify-center">
              <Users className="w-6 h-6 text-[#007FFF]" />
            </div>
            <span className="text-[#007FFF] text-sm">Zapisanych</span>
          </div>
          <div className="text-3xl text-[#1e293b] mb-1">28</div>
          <div className="text-[#64748b]">Skoczków Dzisiaj</div>
        </div>

        <div className="bg-white rounded-xl border-2 border-[#007FFF] p-6 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <div className="w-12 h-12 rounded-full bg-[#e0f2fe] flex items-center justify-center">
              <Cloud className="w-6 h-6 text-[#007FFF]" />
            </div>
            <span className="text-[#22c55e] text-sm">Doskonała</span>
          </div>
          <div className="flex items-center gap-2 mb-1">
            <Wind className="w-5 h-5 text-[#007FFF]" />
            <span className="text-2xl text-[#1e293b]">8 kts</span>
          </div>
          <div className="text-[#64748b]">Prędkość Wiatru NW</div>
        </div>
      </div>

      <div className="bg-[#fff5e6] border border-[#f59e0b] rounded-xl p-4 mb-8 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-[#f59e0b] mt-0.5" />
        <div>
          <div className="text-[#1e293b] mb-1">Alert Bezpieczeństwa</div>
          <p className="text-sm text-[#64748b]">Następny briefing bezpieczeństwa o 14:00 w głównym hangarze. Wszyscy skoczkowie muszą uczestniczyć.</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-[rgba(0,0,0,0.08)] p-6 shadow-sm">
        <h2 className="text-[#1e293b] mb-6">Harmonogram Tygodniowy</h2>

        <div className="grid grid-cols-7 gap-4">
          {weekDays.map((day, index) => {
            const dayEvents = events.filter(e => format(e.date, 'yyyy-MM-dd') === format(day, 'yyyy-MM-dd'));
            const isToday = format(day, 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd');

            return (
              <div key={index} className={`rounded-xl border p-4 ${
                isToday
                  ? 'bg-[#e0f2fe] border-[#007FFF]'
                  : 'bg-[#f8fafc] border-[rgba(0,0,0,0.06)]'
              }`}>
                <div className="text-center mb-3">
                  <div className={`text-sm mb-1 ${isToday ? 'text-[#007FFF]' : 'text-[#64748b]'}`}>
                    {format(day, 'EEE', { locale: pl })}
                  </div>
                  <div className={`text-2xl ${isToday ? 'text-[#007FFF]' : 'text-[#1e293b]'}`}>
                    {format(day, 'd')}
                  </div>
                </div>

                <div className="space-y-2">
                  {dayEvents.map((event, idx) => (
                    <div key={idx} className="bg-white rounded-lg p-2 border border-[rgba(0,0,0,0.06)]">
                      <div className="text-xs text-[#007FFF] mb-1">{event.time}</div>
                      <div className="text-xs text-[#1e293b] leading-tight">{event.title}</div>
                    </div>
                  ))}
                  {dayEvents.length === 0 && (
                    <div className="text-xs text-[#64748b] text-center py-2">Brak wydarzeń</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
