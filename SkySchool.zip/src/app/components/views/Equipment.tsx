import { Package, AlertTriangle, CheckCircle2, Clock, Plus, Search } from "lucide-react";
import { useState } from "react";

interface Rig {
  id: string;
  name: string;
  serialNumber: string;
  mainCanopy: string;
  reserveCanopy: string;
  daysToRepack: number;
  aadStatus: "OK" | "Wygasa" | "Wygasły";
  aadDaysLeft: number;
  lastInspection: string;
  status: "Dostępny" | "W użyciu" | "Serwis";
}

export function Equipment() {
  const [searchTerm, setSearchTerm] = useState("");
  const [rigs] = useState<Rig[]>([
    { id: "1", name: "Zestaw #001", serialNumber: "SN-45789", mainCanopy: "Sabre 3 150", reserveCanopy: "PDR 143", daysToRepack: 142, aadStatus: "OK", aadDaysLeft: 245, lastInspection: "2026-03-15", status: "Dostępny" },
    { id: "2", name: "Zestaw #002", serialNumber: "SN-45790", mainCanopy: "Pilot 168", reserveCanopy: "Optimum 143", daysToRepack: 89, aadStatus: "OK", aadDaysLeft: 312, lastInspection: "2026-02-20", status: "W użyciu" },
    { id: "3", name: "Zestaw #003", serialNumber: "SN-45791", mainCanopy: "Safire 3 129", reserveCanopy: "PDR 126", daysToRepack: 28, aadStatus: "Wygasa", aadDaysLeft: 42, lastInspection: "2026-03-01", status: "Dostępny" },
    { id: "4", name: "Zestaw #004", serialNumber: "SN-45792", mainCanopy: "Sabre 3 135", reserveCanopy: "Smart 120", daysToRepack: 15, aadStatus: "OK", aadDaysLeft: 180, lastInspection: "2026-04-05", status: "Dostępny" },
    { id: "5", name: "Zestaw #005", serialNumber: "SN-45793", mainCanopy: "Katana 120", reserveCanopy: "Optimum 126", daysToRepack: 8, aadStatus: "Wygasa", aadDaysLeft: 25, lastInspection: "2026-04-10", status: "Serwis" },
    { id: "6", name: "Zestaw #006", serialNumber: "SN-45794", mainCanopy: "Spectre 150", reserveCanopy: "PDR 143", daysToRepack: 165, aadStatus: "OK", aadDaysLeft: 290, lastInspection: "2026-01-28", status: "Dostępny" },
  ]);

  const getRepackWarning = (days: number) => {
    if (days <= 30) return "warning";
    return "ok";
  };

  const getAADStatusColor = (status: string) => {
    switch (status) {
      case "OK":
        return "text-[#22c55e]";
      case "Wygasa":
        return "text-[#f59e0b]";
      case "Wygasły":
        return "text-[#ef4444]";
      default:
        return "text-[#64748b]";
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Dostępny":
        return "bg-[#22c55e] text-white";
      case "W użyciu":
        return "bg-[#007FFF] text-white";
      case "Serwis":
        return "bg-[#ef4444] text-white";
      default:
        return "bg-[#64748b] text-white";
    }
  };

  const filteredRigs = rigs.filter(
    (rig) =>
      rig.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rig.serialNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rig.mainCanopy.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-[#1e293b] mb-1">Inwentarz Sprzętu</h1>
          <p className="text-[#64748b]">Zestawy spadochronowe i śledzenie konserwacji</p>
        </div>
        <button className="bg-[#007FFF] text-white px-6 py-3 rounded-xl flex items-center gap-2 hover:bg-[#0066cc] transition-colors">
          <Plus className="w-5 h-5" />
          Dodaj Sprzęt
        </button>
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
          <input
            type="text"
            placeholder="Szukaj po nazwie, numerze seryjnym lub kopule..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-xl border border-[rgba(0,0,0,0.08)] bg-[#f8fafc] focus:outline-none focus:ring-2 focus:ring-[#007FFF] focus:border-transparent"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredRigs.map((rig) => {
          const repackWarning = getRepackWarning(rig.daysToRepack);

          return (
            <div
              key={rig.id}
              className={`bg-white rounded-xl border-2 p-6 shadow-sm transition-all hover:shadow-md ${
                repackWarning === "warning"
                  ? "border-[#f59e0b] bg-[#fffbeb]"
                  : "border-[rgba(0,0,0,0.08)]"
              }`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-[#e0f2fe] flex items-center justify-center">
                    <Package className="w-6 h-6 text-[#007FFF]" />
                  </div>
                  <div>
                    <h3 className="text-[#1e293b]">{rig.name}</h3>
                    <p className="text-sm text-[#64748b]">{rig.serialNumber}</p>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-lg text-sm ${getStatusBadge(rig.status)}`}>
                  {rig.status}
                </span>
              </div>

              <div className="space-y-3 mb-4">
                <div>
                  <div className="text-sm text-[#64748b] mb-1">Kopuła Główna</div>
                  <div className="text-[#1e293b]">{rig.mainCanopy}</div>
                </div>
                <div>
                  <div className="text-sm text-[#64748b] mb-1">Kopuła Zapasowa</div>
                  <div className="text-[#1e293b]">{rig.reserveCanopy}</div>
                </div>
              </div>

              <div className="border-t border-[rgba(0,0,0,0.08)] pt-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-[#64748b]" />
                    <span className="text-sm text-[#64748b]">Dni do Pakowania</span>
                  </div>
                  <div className={`flex items-center gap-1 ${
                    repackWarning === "warning" ? "text-[#f59e0b]" : "text-[#1e293b]"
                  }`}>
                    {repackWarning === "warning" && <AlertTriangle className="w-4 h-4" />}
                    <span>{rig.daysToRepack}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#64748b]" />
                    <span className="text-sm text-[#64748b]">Status AAD</span>
                  </div>
                  <div className={`flex items-center gap-1 ${getAADStatusColor(rig.aadStatus)}`}>
                    <span>{rig.aadStatus}</span>
                    <span className="text-sm">({rig.aadDaysLeft}d)</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm text-[#64748b]">Ostatnia Kontrola</span>
                  <span className="text-sm text-[#1e293b]">{rig.lastInspection}</span>
                </div>
              </div>

              {repackWarning === "warning" && (
                <div className="mt-4 bg-[#f59e0b] bg-opacity-10 border border-[#f59e0b] rounded-lg p-3 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-[#f59e0b] mt-0.5" />
                  <p className="text-sm text-[#1e293b]">
                    Wymagane pakowanie w ciągu 30 dni
                  </p>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
