import { Outlet, Link, useLocation } from "react-router";
import { Plane, Users, Warehouse, Package, Cloud, Wind, Calendar } from "lucide-react";

export function RootLayout() {
  const location = useLocation();

  const navigation = [
    { name: "Panel Główny", path: "/", icon: Plane },
    { name: "Manifest", path: "/manifest", icon: Users },
    { name: "Wyświetlacz Hangar", path: "/hangar", icon: Warehouse },
    { name: "Sprzęt", path: "/equipment", icon: Package },
    { name: "Eventy", path: "/events", icon: Calendar },
  ];

  const isActive = (path: string) => {
    if (path === "/") return location.pathname === "/";
    return location.pathname.startsWith(path);
  };

  return (
    <div className="flex h-screen bg-white">
      <aside className="w-64 bg-[#f8fafc] border-r border-[rgba(0,0,0,0.06)] flex flex-col">
        <div className="p-6 border-b border-[rgba(0,0,0,0.06)]">
          <h1 className="text-[#007FFF] flex items-center gap-2">
            <Plane className="w-6 h-6" />
            SkySchool
          </h1>
          <p className="text-sm text-[#64748b] mt-1">Zarządzanie Strefą Skoków</p>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {navigation.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.path);
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                  active
                    ? "bg-[#007FFF] text-white shadow-sm"
                    : "text-[#64748b] hover:bg-[#e0f2fe] hover:text-[#007FFF]"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.name}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-[rgba(0,0,0,0.06)]">
          <div className="bg-white rounded-xl p-4 shadow-sm border border-[rgba(0,0,0,0.06)]">
            <div className="flex items-center gap-2 mb-3">
              <Cloud className="w-4 h-4 text-[#007FFF]" />
              <span className="text-sm text-[#1e293b]">Pogoda</span>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-[#64748b]">Wiatr</span>
                <span className="text-[#1e293b]">8 kts NW</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#64748b]">Pułap</span>
                <span className="text-[#1e293b]">12,000 ft</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#64748b]">Widoczność</span>
                <span className="text-[#1e293b]">10+ mi</span>
              </div>
            </div>
          </div>
        </div>
      </aside>

      <main className="flex-1 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}
